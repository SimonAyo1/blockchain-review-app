// import { ICompanyProfile } from "./ICompany";

// export const comppppp: ICompanyProfile[] = [
//   {
//     id: 1,
//     name: "Tech Innovators Inc.",
//     tagline: "Innovating the Future",
//     address: "123 Tech Avenue, Silicon Valley, CA",
//     logoUrl:
//       "https://tech-innovations.io/wp-content/uploads/2022/11/Techinnovations-Logo-Color.png",
//     starRating: 0,
//     metrics: {
//       workersSatisfaction: 20,
//       promptPayment: 40,
//       workLifeBalance: 30,
//     },
//     ratings: {
//       averageRating: 0,
//       totalRatings: 0,
//       ratingBreakdown: {
//         fiveStar: 0,
//         fourStar: 0,
//         threeStar: 0,
//         twoStar: 0,
//         oneStar: 0,
//       },
//     },
//     reviews: [],

//     about: ` Lorem ipsum dolor sit amet, consectetur adipiscing
//     elit, sed do eiusmod tempor incididunt ut labore et
//     dolore magna aliqua. Ut enim ad minim veniam, quis
//     nostrud exercitation ullamco laboris nisi ut aliquip
//     ex ea commodo consequat. Duis aute irure dolor in
//     reprehenderit in voluptate velit esse cillum dolore eu
//     fugiat nulla pariatur. Excepteur sint occaecat
//     cupidatat non proident, sunt in culpa qui officia
//     deserunt mollit anim id est laborum.  Lorem ipsum dolor sit amet, consectetur adipiscing
//     elit, sed do eiusmod tempor incididunt ut labore et
//     dolore magna aliqua. Ut enim ad minim veniam, quis
//     nostrud exercitation ullamco laboris nisi ut aliquip
//     ex ea commodo consequat. Duis aute irure dolor in
//     reprehenderit in voluptate velit esse cillum dolore eu
//     fugiat nulla pariatur. Excepteur sint occaecat
//     cupidatat non proident, sunt in culpa qui officia
//     deserunt mollit anim id est laborum.`,
//     country: "United States",
//     industry: ["Natural Gas", "Construction"],
//   },
//   {
//     id: 2,
//     name: "Green Energy Solutions",
//     tagline: "Powering a Sustainable Future",
//     address: "456 Eco Drive, Portland, OR",
//     logoUrl:
//       "https://greenenergysolution.org/wp-content/uploads/2017/07/Logo.png",
//     starRating: 0,
//     metrics: {
//       workersSatisfaction: 80,
//       promptPayment: 60,
//       workLifeBalance: 40,
//     },
//     ratings: {
//       averageRating: 0,
//       totalRatings: 0,
//       ratingBreakdown: {
//         fiveStar: 0,
//         fourStar: 0,
//         threeStar: 0,
//         twoStar: 0,
//         oneStar: 0,
//       },
//     },
//     reviews: [],
//     about: ` Lorem ipsum dolor sit amet, consectetur adipiscing
//     elit, sed do eiusmod tempor incididunt ut labore et
//     dolore magna aliqua. Ut enim ad minim veniam, quis
//     nostrud exercitation ullamco laboris nisi ut aliquip
//     ex ea commodo consequat. Duis aute irure dolor in
//     reprehenderit in voluptate velit esse cillum dolore eu
//     fugiat nulla pariatur. Excepteur sint occaecat
//     cupidatat non proident, sunt in culpa qui officia
//     deserunt mollit anim id est laborum.  Lorem ipsum dolor sit amet, consectetur adipiscing
//     elit, sed do eiusmod tempor incididunt ut labore et
//     dolore magna aliqua. Ut enim ad minim veniam, quis
//     nostrud exercitation ullamco laboris nisi ut aliquip
//     ex ea commodo consequat. Duis aute irure dolor in
//     reprehenderit in voluptate velit esse cillum dolore eu
//     fugiat nulla pariatur. Excepteur sint occaecat
//     cupidatat non proident, sunt in culpa qui officia
//     deserunt mollit anim id est laborum.`,
//     country: "United States",
//     industry: ["Natural Gas", "Water Supply"],
//   },
//   {
//     id: 3,
//     name: "Health First Medical",
//     tagline: "Your Health, Our Priority",
//     address: "789 Health St, Boston, MA",
//     logoUrl:
//       "https://www.healthfirstmc.com/wp-content/uploads/2019/03/HealthFirstMedicalCenter-1.png",
//     starRating: 0,
//     metrics: {
//       workersSatisfaction: 50,
//       promptPayment: 10,
//       workLifeBalance: 60,
//     },
//     ratings: {
//       averageRating: 0,
//       totalRatings: 0,
//       ratingBreakdown: {
//         fiveStar: 0,
//         fourStar: 0,
//         threeStar: 0,
//         twoStar: 0,
//         oneStar: 0,
//       },
//     },
//     reviews: [],
//     about: ` Lorem ipsum dolor sit amet, consectetur adipiscing
//     elit, sed do eiusmod tempor incididunt ut labore et
//     dolore magna aliqua. Ut enim ad minim veniam, quis
//     nostrud exercitation ullamco laboris nisi ut aliquip
//     ex ea commodo consequat. Duis aute irure dolor in
//     reprehenderit in voluptate velit esse cillum dolore eu
//     fugiat nulla pariatur. Excepteur sint occaecat
//     cupidatat non proident, sunt in culpa qui officia
//     deserunt mollit anim id est laborum.  Lorem ipsum dolor sit amet, consectetur adipiscing
//     elit, sed do eiusmod tempor incididunt ut labore et
//     dolore magna aliqua. Ut enim ad minim veniam, quis
//     nostrud exercitation ullamco laboris nisi ut aliquip
//     ex ea commodo consequat. Duis aute irure dolor in
//     reprehenderit in voluptate velit esse cillum dolore eu
//     fugiat nulla pariatur. Excepteur sint occaecat
//     cupidatat non proident, sunt in culpa qui officia
//     deserunt mollit anim id est laborum.`,
//     country: "United States",
//     industry: ["Health", "Medicine"],
//   },
//   {
//     id: 4,
//     name: "EduTech Pioneers",
//     tagline: "Empowering Education through Technology",
//     address: "101 Learning Blvd, Austin, TX",
//     logoUrl: "https://www.edutech.com/tools/img/logo.png",
//     starRating: 0,
//     metrics: {
//       workersSatisfaction: 60,
//       promptPayment: 70,
//       workLifeBalance: 90,
//     },
//     ratings: {
//       averageRating: 0,
//       totalRatings: 0,
//       ratingBreakdown: {
//         fiveStar: 0,
//         fourStar: 0,
//         threeStar: 0,
//         twoStar: 0,
//         oneStar: 0,
//       },
//     },
//     reviews: [],
//     about: ` Lorem ipsum dolor sit amet, consectetur adipiscing
//     elit, sed do eiusmod tempor incididunt ut labore et
//     dolore magna aliqua. Ut enim ad minim veniam, quis
//     nostrud exercitation ullamco laboris nisi ut aliquip
//     ex ea commodo consequat. Duis aute irure dolor in
//     reprehenderit in voluptate velit esse cillum dolore eu
//     fugiat nulla pariatur. Excepteur sint occaecat
//     cupidatat non proident, sunt in culpa qui officia
//     deserunt mollit anim id est laborum.  Lorem ipsum dolor sit amet, consectetur adipiscing
//     elit, sed do eiusmod tempor incididunt ut labore et
//     dolore magna aliqua. Ut enim ad minim veniam, quis
//     nostrud exercitation ullamco laboris nisi ut aliquip
//     ex ea commodo consequat. Duis aute irure dolor in
//     reprehenderit in voluptate velit esse cillum dolore eu
//     fugiat nulla pariatur. Excepteur sint occaecat
//     cupidatat non proident, sunt in culpa qui officia
//     deserunt mollit anim id est laborum.`,
//     country: "Germany",
//     industry: ["Education"],
//   },
//   {
//     id: 5,
//     name: "Fintech Innovators",
//     tagline: "Revolutionizing Finance",
//     address: "202 Wall Street, New York, NY",
//     logoUrl:
//       "https://fintech-i.com/wp-content/uploads/2023/09/FinTech_Innovators_white_250x98.png",
//     starRating: 0,
//     metrics: {
//       workersSatisfaction: 30,
//       promptPayment: 50,
//       workLifeBalance: 60,
//     },
//     ratings: {
//       averageRating: 0,
//       totalRatings: 0,
//       ratingBreakdown: {
//         fiveStar: 0,
//         fourStar: 0,
//         threeStar: 0,
//         twoStar: 0,
//         oneStar: 0,
//       },
//     },
//     reviews: [],
//     about: ` Lorem ipsum dolor sit amet, consectetur adipiscing
//     elit, sed do eiusmod tempor incididunt ut labore et
//     dolore magna aliqua. Ut enim ad minim veniam, quis
//     nostrud exercitation ullamco laboris nisi ut aliquip
//     ex ea commodo consequat. Duis aute irure dolor in
//     reprehenderit in voluptate velit esse cillum dolore eu
//     fugiat nulla pariatur. Excepteur sint occaecat
//     cupidatat non proident, sunt in culpa qui officia
//     deserunt mollit anim id est laborum.  Lorem ipsum dolor sit amet, consectetur adipiscing
//     elit, sed do eiusmod tempor incididunt ut labore et
//     dolore magna aliqua. Ut enim ad minim veniam, quis
//     nostrud exercitation ullamco laboris nisi ut aliquip
//     ex ea commodo consequat. Duis aute irure dolor in
//     reprehenderit in voluptate velit esse cillum dolore eu
//     fugiat nulla pariatur. Excepteur sint occaecat
//     cupidatat non proident, sunt in culpa qui officia
//     deserunt mollit anim id est laborum.`,
//     country: "United States",
//     industry: ["Finance"],
//   },
//   {
//     id: 6,
//     name: "Urban Development Co.",
//     tagline: "Building the Future",
//     address: "303 City Road, Chicago, IL",
//     logoUrl: "https://udcja.com/wp-content/uploads/2021/07/logo11.png",
//     starRating: 0,
//     metrics: {
//       workersSatisfaction: 50,
//       promptPayment: 20,
//       workLifeBalance: 10,
//     },
//     ratings: {
//       averageRating: 0,
//       totalRatings: 0,
//       ratingBreakdown: {
//         fiveStar: 0,
//         fourStar: 0,
//         threeStar: 0,
//         twoStar: 0,
//         oneStar: 0,
//       },
//     },
//     reviews: [],
//     about: ` Lorem ipsum dolor sit amet, consectetur adipiscing
//     elit, sed do eiusmod tempor incididunt ut labore et
//     dolore magna aliqua. Ut enim ad minim veniam, quis
//     nostrud exercitation ullamco laboris nisi ut aliquip
//     ex ea commodo consequat. Duis aute irure dolor in
//     reprehenderit in voluptate velit esse cillum dolore eu
//     fugiat nulla pariatur. Excepteur sint occaecat
//     cupidatat non proident, sunt in culpa qui officia
//     deserunt mollit anim id est laborum.  Lorem ipsum dolor sit amet, consectetur adipiscing
//     elit, sed do eiusmod tempor incididunt ut labore et
//     dolore magna aliqua. Ut enim ad minim veniam, quis
//     nostrud exercitation ullamco laboris nisi ut aliquip
//     ex ea commodo consequat. Duis aute irure dolor in
//     reprehenderit in voluptate velit esse cillum dolore eu
//     fugiat nulla pariatur. Excepteur sint occaecat
//     cupidatat non proident, sunt in culpa qui officia
//     deserunt mollit anim id est laborum.`,
//     country: "United States",
//     industry: ["Construction"],
//   },
//   {
//     id: 7,
//     name: "AgriBusiness Inc.",
//     tagline: "Feeding the World",
//     address: "404 Farm Lane, Omaha, NE",
//     logoUrl:
//       "https://img1.wsimg.com/isteam/ip/61ba2854-623d-4a36-b639-b3cbb6cac2d5/aba_logo-0001.png/:/rs=h:74,cg:true,m/qt=q:100/ll",
//     starRating: 0,
//     metrics: {
//       workersSatisfaction: 20,
//       promptPayment: 60,
//       workLifeBalance: 20,
//     },
//     ratings: {
//       averageRating: 0,
//       totalRatings: 0,
//       ratingBreakdown: {
//         fiveStar: 0,
//         fourStar: 0,
//         threeStar: 0,
//         twoStar: 0,
//         oneStar: 0,
//       },
//     },
//     reviews: [],
//     about: ` Lorem ipsum dolor sit amet, consectetur adipiscing
//     elit, sed do eiusmod tempor incididunt ut labore et
//     dolore magna aliqua. Ut enim ad minim veniam, quis
//     nostrud exercitation ullamco laboris nisi ut aliquip
//     ex ea commodo consequat. Duis aute irure dolor in
//     reprehenderit in voluptate velit esse cillum dolore eu
//     fugiat nulla pariatur. Excepteur sint occaecat
//     cupidatat non proident, sunt in culpa qui officia
//     deserunt mollit anim id est laborum.  Lorem ipsum dolor sit amet, consectetur adipiscing
//     elit, sed do eiusmod tempor incididunt ut labore et
//     dolore magna aliqua. Ut enim ad minim veniam, quis
//     nostrud exercitation ullamco laboris nisi ut aliquip
//     ex ea commodo consequat. Duis aute irure dolor in
//     reprehenderit in voluptate velit esse cillum dolore eu
//     fugiat nulla pariatur. Excepteur sint occaecat
//     cupidatat non proident, sunt in culpa qui officia
//     deserunt mollit anim id est laborum.`,
//     country: "United States",
//     industry: ["Agriculture"],
//   },
// ];
